---
name: i2v-4steps-1.0.0
author: Jiaqi
description: "(Image to Video in 4 Steps + Spatial Blocking + Unified KB Manifest) Generates a 9-grid storyboard and a time-stamped Seedance 2.0 video prompt from a script. This version uses a Unified KB Manifest architecture: all KB indexes are consolidated into a single KB_MASTER_MANIFEST.json, reducing manifest reads from 15 to 1. Decision rules are embedded in SKILL.md, full parameter tables are loaded on-demand only for the selected options."
---
# Skill: i2v-4steps-1.0.0 (Unified KB Manifest Architecture)

**Author**: Jiaqi

## Overview

This skill generates a **9-grid storyboard prompt** and a **time-stamped Seedance 2.0 video prompt** from a script.

**Core Architecture -- Unified KB Manifest**:
- **Index Layer** (embedded below): Decision rules, selection menus, and trigger conditions for all KBs. Read once with SKILL.md.
- **Detail Layer** (in `references/` folder): Full parameter tables, examples, and keyword lists. **Load ONLY the sections you actually need** after making decisions from the Index Layer.
- **Unified Manifest** (in `references/` folder): A single `KB_MASTER_MANIFEST.json` file contains the section index for ALL 15 KB files. **Read once at task start, then use it to locate sections in any KB file by line range.**
- **Result**: Manifest reads reduced from 15 to 1. No content is deleted -- all original KB files remain intact in `references/`.

**Core Principle**: Execute the four steps in strict sequential order. Use the embedded Index Layer to make decisions, then use the unified manifest to locate the exact line range, and read only those lines from the KB file.

**Manifest-Based Loading Protocol** (for all targeted reads):
1. Read `references/KB_MASTER_MANIFEST.json` once at the start of the task (contains indexes for all 15 KB files).
2. Find the target KB by its key name (e.g., `KB_Editing_Styles`), then find the section entry matching your selected item (by title keyword match).
3. Use `file read` with `range: [start_line, end_line]` to load only that section from the original KB file.
4. This protocol replaces any "search by heading" instructions. No grep or text search tools required.

---

## ===============================================
## INDEX LAYER: Step 1 -- Artistic Vision
## ===============================================

### IDX-1A: Narrative Patterns (叙事弧光选择菜单)

> Source: `references/KB_Narrative_Patterns.md` -- Read detail ONLY for the selected pattern.

| 弧光类型 | 一句话描述 | 适用场景 |
|:---|:---|:---|
| **渐强式 (Crescendo)** | 紧张感持续累积，在结尾爆发 | 悬疑、恐怖、动作高潮 |
| **爆发-衰减式 (Burst-Decay)** | 开头强烈冲击，然后逐渐平复 | 战争后果、灾难余波 |
| **波浪式 (Wave)** | 情绪起伏交替，多次小高潮 | 情感剧、关系变化 |
| **平稳-突变式 (Plateau-Shift)** | 长时间平静后突然转折 | 日常→意外、反转 |
| **循环式 (Circular)** | 首尾呼应，回到起点但含义改变 | 文艺片、哲理叙事 |
| **下降式 (Descending)** | 从希望到绝望的持续下坠 | 悲剧、黑色电影 |

**选择规则**: 分析脚本的情感走向，选择最匹配的1种弧光。商业类脚本优先考虑渐强式或波浪式。

### IDX-1B: Editing Styles (剪辑风格选择菜单)

> Source: `references/KB_Editing_Styles.md` -- Read detail ONLY for the selected style.

| 剪辑风格 | 一句话描述 | 节奏特征 | 适用场景 |
|:---|:---|:---|:---|
| **呼吸式 (Breathing)** | 模拟自然呼吸节奏，张弛有度 | 中速，有规律的快慢交替 | 生活类、美妆、ASMR |
| **脉冲式 (Pulse)** | 稳定节拍驱动，像心跳一样规律 | 中快速，均匀节拍 | 产品展示、科技、运动 |
| **沉思式 (Contemplative)** | 缓慢、沉浸、留白丰富 | 慢速，长镜头为主 | 文艺片、情感叙事 |
| **极限频闪式 (Extreme Strobe-Cut)** | 极快速碎片化剪辑，视觉冲击 | 极快，0.5-1秒切换 | 动作、战斗、MV |
| **蒙太奇式 (Montage)** | 通过并列画面传达抽象概念 | 中速，画面关联性强 | 时间流逝、对比叙事 |
| **长镜头式 (Long Take)** | 一镜到底或极少剪辑 | 极慢，连续运镜 | 纪录片、沉浸体验 |

**选择规则**: 根据脚本类型和情感基调选择。商业带货类优先呼吸式/脉冲式；叙事类根据情感选择。

### IDX-1C: Sound Narrative (声音基调选择菜单)

> Source: `references/KB_Sound_Narrative.md` -- Read detail ONLY for the selected techniques.

**10种声音叙事技巧速查表：**

| 技巧名称 | 一句话描述 | 情感效果 |
|:---|:---|:---|
| **声音打断 (Sound Interrupt)** | 突然的声音切断打破连续性 | 震惊、警觉 |
| **声音特写 (Sound Close-Up)** | 放大某个微小声音的细节 | 亲密、紧张 |
| **主观声音 (Subjective Sound)** | 从角色主观听觉出发的声音 | 代入感、孤立感 |
| **战略性沉默 (Strategic Silence)** | 有意的完全静默 | 悬念、压迫、期待 |
| **声音蒙太奇 (Sound Montage)** | 多种声音快速叠加 | 混乱、信息过载 |
| **渐强音墙 (Crescendo Wall)** | 声音层层叠加直到爆发 | 紧张累积、高潮 |
| **声音倒叙 (Sound Flashback)** | 用过去的声音触发回忆 | 怀旧、创伤 |
| **环境浸入 (Ambient Immersion)** | 丰富的环境音营造空间感 | 沉浸、真实 |
| **声音对位 (Sound Counterpoint)** | 声音与画面形成反差 | 讽刺、不安 |
| **节奏锚定 (Rhythm Anchor)** | 用重复的声音建立节奏 | 催眠、仪式感 |

**情绪→声音技巧映射表：**

| 情绪 | 推荐技巧组合 |
|:---|:---|
| 紧张/悬疑 | 战略性沉默 + 声音特写 + 渐强音墙 |
| 震惊/冲击 | 声音打断 + 主观声音 |
| 温馨/日常 | 环境浸入 + 节奏锚定 |
| 悲伤/怀旧 | 声音倒叙 + 战略性沉默 |
| 混乱/疯狂 | 声音蒙太奇 + 声音打断 |
| 讽刺/反转 | 声音对位 |

**声音弧线模型**：声音设计应与叙事弧光同步。渐强式弧光→声音从稀疏到密集；爆发式→声音从爆裂到稀疏。

---

## ===============================================
## INDEX LAYER: Step 2 -- Visual Storyboard
## ===============================================

### IDX-2A: Cinematic Composition (构图技法选择菜单)

> Source: `references/KB_Cinematic_Composition.md` -- Read detail for the techniques you plan to use.

| 构图技法 | 一句话描述 | 适用景别 |
|:---|:---|:---|
| **三分法 (Rule of Thirds)** | 主体放在1/3交叉点 | 所有景别 |
| **中心构图 (Center Framing)** | 主体居中，对称感 | 特写、中景 |
| **框中框 (Frame within Frame)** | 用前景元素框住主体 | 中景、全景 |
| **引导线 (Leading Lines)** | 线条引导视线到主体 | 全景、远景 |
| **前景虚化 (Foreground Bokeh)** | 前景模糊创造深度 | 中景、特写 |
| **对角线构图 (Diagonal)** | 主体沿对角线排列 | 动态场景 |
| **负空间 (Negative Space)** | 大面积留白突出主体 | 远景、情感场景 |
| **过肩镜头 (OTS)** | 从一个角色肩膀看另一个 | 对话场景 |
| **荷兰角 (Dutch Angle)** | 倾斜构图制造不安 | 悬疑、心理 |
| **深焦构图 (Deep Focus)** | 前中后景都清晰 | 叙事复杂场景 |

**主观镜头表 (POV Shots)：**

| 主观类型 | 描述 | 情绪效果 |
|:---|:---|:---|
| **角色POV** | 从角色眼睛看出去 | 强代入感 |
| **物体POV** | 从物体视角看（如镜子、手机屏幕） | 新奇、悬疑 |
| **窥视POV** | 通过缝隙/孔洞窥视 | 偷窥感、紧张 |
| **倒地POV** | 躺在地上仰视 | 无力、绝望 |

**景别x构图推荐**：特写→中心/三分法；中景→OTS/框中框；全景→引导线/负空间；远景→负空间/深焦。

### IDX-2B: Camera Choreography (运镜类型选择菜单)

> Source: `references/KB_Camera_Choreography.md` -- Read detail for the movements you plan to use.

| 运镜类型 | 情感功能 | 适用场景 |
|:---|:---|:---|
| **静止 (Static)** | 稳定、客观、观察 | 对话、产品展示 |
| **缓推 (Slow Push-In)** | 逐渐聚焦、紧张累积 | 悬疑揭示、情感升温 |
| **缓拉 (Slow Pull-Out)** | 揭示环境、孤独感 | 结局、全景展示 |
| **横移 (Lateral Track)** | 跟随、平行叙事 | 行走、巡视 |
| **弧形环绕 (Arc)** | 360度审视、戏剧性 | 角色亮相、对峙 |
| **手持 (Handheld)** | 真实、紧张、不安 | 追逐、冲突 |
| **升降 (Crane/Jib)** | 宏大、揭示、权力 | 开场、结局 |
| **甩镜头 (Whip Pan)** | 突然转向、惊讶 | 反转、快速切换 |
| **变焦 (Zoom)** | 突出、压缩空间 | 发现、震惊 |
| **跟焦 (Rack Focus)** | 注意力转移 | 前后景切换 |

**连续帧运镜规则**：相邻帧不得使用相同运镜类型。9帧中至少使用4种不同运镜。

### IDX-2C: Lighting & Camera Equipment

> `references/KB_Lighting_Atmosphere.md` -- 143行，**全量读取**（灯光查询表 + 色彩系统，不拆分）
> `references/KB_Camera_Guide.md` -- 81行，**全量读取**（设备型号表，不拆分，所有型号完整保留）

**注意**：这两个KB体量小且为查询表结构，Step 2中直接全量读取。

### IDX-2D: Color System (色彩系统选择菜单)

> Source: `references/KB_Lighting_Atmosphere.md` §3 -- 随 Step 2 全量读取时一并加载。

**色温选择（5档，逐帧应用）：**

| 色温范围 | 英文关键词 | 情绪/氛围 |
|:---|:---|:---|
| 1800-2700K | `Ultra Warm White`, `Candlelight`, `1800K` | 温馨、怀旧、浪漫、神秘 |
| 3000-3500K | `Warm White`, `Golden Hour Light`, `3200K` | 舒适、亲密、黄金时刻 |
| 4000-5000K | `Neutral White`, `Natural Daylight`, `4500K` | 自然、真实、平衡、现代 |
| 5500-6500K | `Daylight White`, `Cool White`, `6500K` | 清晰、活力、临床、办公 |
| 7000-10000K+ | `Cool Blue`, `Deep Blue Sky`, `8000K` | 冷峻、疏离、科幻、未来 |

**饱和度选择（7档，全局应用）：**

| 等级 | 英文关键词 | 情绪/氛围 |
|:---|:---|:---|
| -100 | `Black and White`, `Monochrome` | 经典、永恒、戏剧性、严肃 |
| -50 | `Heavily Desaturated`, `Muted Tones` | 压抑、忧郁、末日、回忆 |
| -25 | `Slightly Desaturated`, `Subtle Colors` | 现实、冷静、高级感、纪录片 |
| 0 | `Natural Saturation`, `True to Life Colors` | 真实、平衡、自然 |
| +25 | `Slightly Oversaturated`, `Vibrant Colors` | 活力、热情、商业、乐观 |
| +50 | `Highly Saturated`, `Rich Colors` | 梦幻、戏剧、波普艺术、儿童 |
| +75 | `Extremely Saturated`, `Hyper-real Colors` | 迷幻、超现实、视觉冲击 |

**色彩基调选择（7种，全局应用）：**

| 基调 | 英文关键词 | 情绪/氛围 |
|:---|:---|:---|
| 单色 | `Monochromatic Palette` | 统一、和谐、极简、宁静或压抑 |
| 类似色 | `Analogous Palette` | 和谐、舒适、自然、低对比度 |
| 互补色 | `Complementary Palette`, `Split-Toning` | 冲突、活力、高对比度、视觉焦点 |
| 三色 | `Triadic Palette` | 平衡、多样、充满活力 |
| 粉彩色 | `Pastel Palette` | 柔和、梦幻、童话、女性化 |
| 大地色 | `Earth Tone Palette` | 质朴、温暖、稳定、有机 |
| 霓虹色 | `Neon Palette`, `Cyberpunk Colors` | 未来、都市、迷幻、反乌托邦 |

**选择规则**: Step 1 分析脚本时确定色温基准(可逐帧微调)+饱和度+色彩基调各 1 项，写入`电影技术规格`。色温在每帧灯光行中可根据光源类型微调，饱和度和色彩基调写入 STYLE 行作为全局参数。

---

## ===============================================
## INDEX LAYER: Step 3 -- Video Prompt
## ===============================================

### IDX-3A: Seedance 2.0 Prompt Format (格式骨架)

> Source: `references/KB_Seedance2_Prompt_Format.md` -- 仅在首次使用时读取详情学习完整格式。后续可跳过。

**格式骨架（必记）：**

```
No subtitles.
参考[九宫格]进行剧情延展

[体验定义层: 剪辑风格 + 感官/艺术风格，<=80字符]

[0-t1秒]
[运镜+微表演+动作], [资产名称]标签。
音效: [单行<=40字符], [声音技巧名]
旁白(情绪): "台词"

[t1-t2秒]
...
```

**关键规则速查**：
- 总字符 <= 1000
- 视觉指令占~80%，音效占~20%
- 每个时间段MUST有`音效:`行
- MUST NOT包含相机/镜头型号
- 关键时刻MUST包含微表演（至少覆盖2个区域）
- 对白内嵌到`音效:`行或单独`对白:`行

### IDX-3B: 9-Beat to Seedance Mapping (蒙太奇重构选择菜单)

> Source: `references/KB_9Beat_to_Seedance_Mapping.md` -- Read detail for the selected narrative pattern.

| 叙事模式 | 蒙太奇结构 | Beat组织方式 |
|:---|:---|:---|
| **线性叙事** | 顺序序列 | 1→2→3→...→9 |
| **闪回叙事** | 插入式序列 | 5→(1-2)→5→8-9 |
| **平行/交叉叙事** | 交替序列 | 1→6→2→7→3→8 |
| **倒叙** | 逆序序列 | 9→8→...→1 |
| **意识流** | 碎片化序列 | 5→1→9→3→7... |
| **高燃时刻** | 沙漏模型(固定) | (1-4)→(5)→(6-9) |

**规则**：优先非线性（除非脚本明确要求线性）；剪辑风格决定结构。

### IDX-3C: Rhythm & Pacing (节奏模式选择菜单)

> Source: `references/KB_Rhythm_Pacing.md` -- Read detail for the selected rhythm pattern.

| 节奏模式 | 时长分配特征 | 适用弧光 |
|:---|:---|:---|
| **渐强式 (Crescendo)** | 视听块时长逐渐缩短 | 渐强式弧光 |
| **爆发-衰减式 (Burst-Decay)** | 极短冲击块+逐渐增长的后续块 | 爆发-衰减式弧光 |
| **交错式 (Intercut)** | 两个不同时长的块交替 | 平行叙事 |
| **沙漏模型 (Sandglass)** | 快→慢→快 | 高燃时刻 |

**VO时长公式**：`台词字数上限 = 视听块时长(秒) x 基准语速 x 情绪修正系数`
- 商业类基准语速: 3.0字/秒 | 叙事类: 2.8字/秒

**时间分配原则**：
- 情感高潮分配最长时间(4-6秒)
- 快速过渡用极短时间(0.5-1秒)
- 关键时刻后可留1-2秒空镜头
- 最小0.5秒，最大6秒

### IDX-3D: Micro-Performance (微表演区域速查)

> Source: `references/KB_Micro_Performance.md` -- Read detail ONLY for the emotions needed in the current segment.

**5大面部区域定义：**

| 区域 | 代号 | 覆盖范围 |
|:---|:---|:---|
| 眼部 | Z1 | 瞳孔、眼睑、眉毛、泪腺 |
| 口部 | Z2 | 嘴唇、下颌、牙齿 |
| 皮肤/肌肉 | Z3 | 面部肌肉、血管、汗腺 |
| 手部/肢体 | Z4 | 手指、手掌、手臂微动作 |
| 呼吸/躯干 | Z5 | 胸腔起伏、肩膀、颈部 |

**情绪→区域激活映射表：**

| 情绪 | 主激活区域 | 次激活区域 |
|:---|:---|:---|
| 恐惧 | Z1(瞳孔放大) | Z5(呼吸急促), Z3(苍白) |
| 愤怒 | Z1(眉头紧锁)+Z2(咬牙) | Z3(青筋), Z4(握拳) |
| 悲伤 | Z1(泪水)+Z2(嘴角下垂) | Z5(肩膀塌陷) |
| 惊讶 | Z1(瞳孔收缩)+Z2(嘴巴微张) | Z5(倒吸气) |
| 决绝 | Z1(目光如钢)+Z2(抿唇) | Z3(太阳穴青筋), Z4(握紧) |
| 焦虑 | Z1(眼神游移) | Z4(手指摩擦), Z5(浅快呼吸) |
| 喜悦 | Z1(眼角弯起)+Z2(嘴角上扬) | Z3(脸颊泛红), Z5(深呼吸) |
| 绝望 | Z1(空洞目光)+Z2(嘴唇颤抖) | Z3(面色灰白), Z5(呼吸微弱) |
| 觉醒 | Z1(瞳孔骤然聚焦) | Z3(血色回涌), Z5(猛然挺直) |
| 疯狂 | Z1(瞳孔不规则扩缩)+Z2(不自主微笑) | Z3(面部肌肉抽搐), Z4(手指痉挛) |
| 英勇 | Z1(坚定直视)+Z2(嘴角微扬) | Z3(伤口渗血但无视), Z5(挺胸) |

**微表演写法规则**：
- 关键时刻MUST覆盖至少2个区域
- 用具体生理描写替代模糊情绪词（"他很害怕" → "瞳孔骤然放大，指尖不可控地颤抖"）
- 鼓励使用通感比喻（"冰冷的月光浇在脸上"）

**情绪转折三段式写法**：
1. **起始情绪**：用Z1+Z2建立初始状态
2. **转折触发**：描写外部刺激
3. **终止情绪**：用Z1+Z2+Z3展现变化后的状态

**5种微表演动态模式**：
- **渐变式**：情绪缓慢过渡（眼中的光芒一点点熄灭）
- **突变式**：瞬间切换（笑容凝固，瞳孔骤缩）
- **压抑式**：内心翻涌但外表克制（嘴角微微颤抖是唯一的破绽）
- **爆发式**：长期压抑后突然释放（泪水决堤般涌出）
- **矛盾式**：两种情绪同时存在（嘴角在笑，眼中却是冰冷的恨意）

**5种比喻类型**：
- **温度比喻**：冰冷的/灼热的/温暖的
- **材质比喻**：钢铁般的/玻璃般的/丝绸般的
- **自然比喻**：如暴风雨般/如潮水般/如岩石般
- **光影比喻**：光芒熄灭/阴影笼罩/光芒万丈
- **液体比喻**：泪水决堤/血色涌上/冷汗渗出

### IDX-3E: Dialogue Pacing & Transitions

> `references/KB_Dialogue_Pacing.md` -- 57行，**全量读取**
> `references/KB_Cinematic_Transitions.md` -- 72行，**全量读取**

---

## ===============================================
## INDEX LAYER: Step 4 -- HTM (Conditional)
## ===============================================

### IDX-4A: HTM Trigger Conditions

> Source: `references/KB_Frozen_Moment.md` -- Read detail ONLY if HTM is triggered.

| 触发类别 | 触发关键词 |
|:---|:---|
| **物理冲击** | 拳头命中, 重击, 踢碎, 碰撞, 撞击, 爆炸, 斩击, 格挡, 闪避, 子弹穿过 |
| **关键转折** | 觉醒, 变身, 能量爆发, 释放, 挣脱, 关键一枪 |
| **产品展示** | 产品变形, 液体飞溅, 零件组合, 极限性能展示 |

**沙漏模型概要（4阶段）**：
1. 蓄力/切入 (0-2s): 快速运镜进入
2. 冲击/凝固 (2-8s): 时间膨胀，微表演+VFX
3. 后果/释放 (8-12s): 速度恢复
4. 余韵/结局 (12-15s): 全局展示

**检查清单**：视听块结构 | 微表演>=2角色 | 声音叙事匹配变速 | VFX>=2分类 | 沙漏节奏 | 运镜>=4种 | 无九宫格引用 | <=1000字符

### IDX-4B: Combat VFX (分类总览)

> Source: `references/KB_Combat_VFX.md` -- Read detail ONLY for the VFX categories needed.

| 编号 | VFX分类 | 关键词数 | 适用场景 |
|:---|:---|:---|:---|
| 1 | 冲击与碎片 (Impact & Debris) | 15 | 拳脚交锋、爆炸 |
| 2 | 火焰与爆炸 (Fire & Explosions) | 12 | 爆破、燃烧 |
| 3 | 烟雾与大气 (Smoke & Atmosphere) | 14 | 战场氛围 |
| 4 | 火花与电弧 (Sparks & Electricity) | 10 | 金属碰撞、科幻 |
| 5 | 水与天气 (Water & Weather) | 12 | 雨战、暴风雪 |
| 6 | 能量与魔法 (Energy & Magic) | 10 | 科幻、超能力 |
| 7 | 物理反馈 (Physical Feedback) | 12 | 身体反应、材质变形 |
| 8 | 速度与时间 (Speed & Time) | 8 | 变速、子弹时间 |
| 9 | 光效与镜头 (Optics & Lens FX) | 8 | 光学特效 |

**T=0帧规则**：凝固瞬间必须包含至少2种不同分类的VFX关键词。

**动作动词速查**：strike, smash, slash, thrust, punch, kick, slam, crush, pierce, shatter, parry, block, deflect, dodge, sprint, dash, lunge, vault, stagger, recoil, explode, shatter, crack, disintegrate

---

## ===============================================
## THE 4-STEP WORKFLOW
## ===============================================

### **Step 1: Define the Artistic Vision**

**Goal**: Analyze the script and establish the core creative direction.

**Execution**:
1. Read the user's script. Identify video type (**Commercial** or **Narrative**).
2. Using **IDX-1A** above, select 1 Narrative Pattern. Then use **Manifest-Based Loading Protocol**: look up `KB_Narrative_Patterns` in `references/KB_MASTER_MANIFEST.json`, find the selected pattern's line range, and read only those lines from `references/KB_Narrative_Patterns.md`.
3. Using **IDX-1B** above, select 1 Editing Style. Then use **Manifest-Based Loading Protocol**: look up `KB_Editing_Styles` in `references/KB_MASTER_MANIFEST.json`, find the selected style's line range, and read only those lines from `references/KB_Editing_Styles.md`.
4. Using **IDX-1C** above, select 2-3 Sound Techniques. Then use **Manifest-Based Loading Protocol**: look up `KB_Sound_Narrative` in `references/KB_MASTER_MANIFEST.json`, find each selected technique's line range, and read only those lines from `references/KB_Sound_Narrative.md`.
5. Using **IDX-2D** above, select color temperature baseline (1 of 5), saturation (1 of 7), and color palette (1 of 7) based on the script's emotional tone and visual style.
6. Produce the `## 电影技术规格` and `## 资产映射表` sections. **资产映射表中的资产名称 MUST 使用用户系统语言**（如中文用户则用中文命名），资产类型同样使用系统语言（角色/场景/道具）。`色彩与风格` 字段 MUST 结构化输出色温、饱和度、色彩基调三项参数。

**KB Read Summary**: 1 unified manifest read (at task start) + ~3 targeted KB reads (selected sections only).

**STOP. Do not proceed to Step 2 until the Artistic Vision is finalized.**

---

### **Step 2: Generate the 9-Grid Storyboard Prompt**

**Goal**: Translate the script and Artistic Vision into a static, 9-frame visual plan.

**Execution**:
1. Use the script and `艺术愿景` from Step 1.
2. Read `references/KB_Lighting_Atmosphere.md` in full (143 lines, includes §3 Color System).
3. Read `references/KB_Camera_Guide.md` in full (81 lines).
4. Using **IDX-2A** and **IDX-2B** above, plan which composition techniques and camera movements to use for each frame. Then use **Manifest-Based Loading Protocol**: look up `KB_Cinematic_Composition` and `KB_Camera_Choreography` in `references/KB_MASTER_MANIFEST.json`, find each selected technique/movement's line range, and read only those lines from the respective KB files.
5. Create the `## 分段 X 分镜计划` table with `空间站位` column.
6. **Spatial Blocking Continuity Rule**:
   - Frame 1 establishes initial blocking for all characters.
   - Frames 2-9: write `继承帧N` if unchanged, or explicit movement delta + motivation.
   - Characters MUST NOT teleport. FG/MG/BG placement MUST match `空间站位`.
7. Write the complete `## 分段 X 九宫格分镜提示词`.

**KB Read Summary**: 2 full small files + targeted reads from 2 large files (using the already-loaded unified manifest).

**STOP. Do not proceed to Step 3 until the 9-grid prompt is complete.**

---

### **Step 3: Compliance Gate & Seedance 2.0 Video Prompt Generation**

**Goal**: Audit the storyboard and generate the final video prompt.

**Part A -- MANDATORY Compliance Gate**:
1. Audit the 9-Grid Prompt against:
   - **Rule 1 -- Asset Chain**: Every frame has `[角色]+[场景]+[道具]`.
   - **Rule 2 -- Three-Layer**: Every frame has `FG:` + `MG:` + `BG:`.
   - **Rule 3 -- Bilingual**: Narrative in system language, technical in English.
   - **Rule 4 -- Spatial Blocking**: No teleportation, FG/MG/BG matches `空间站位`.
   - **Rule 5 -- Color Consistency**: STYLE行包含色彩基调+饱和度英文关键词；每帧灯光行包含色温英文关键词；且与`电影技术规格`中的选择一致。
2. If any frame fails, fix before proceeding.

**Part B -- Video Prompt Generation**:
1. Using **IDX-3A** format skeleton above (if first time, also read `references/KB_Seedance2_Prompt_Format.md` for full examples via manifest).
2. Using **IDX-3B**, select montage structure. Then use **Manifest-Based Loading Protocol**: look up `KB_9Beat_to_Seedance_Mapping` in `references/KB_MASTER_MANIFEST.json`, find the selected structure's line range, and read only those lines from `references/KB_9Beat_to_Seedance_Mapping.md`.
3. Using **IDX-3C**, select rhythm pattern. Then use **Manifest-Based Loading Protocol**: look up `KB_Rhythm_Pacing` in `references/KB_MASTER_MANIFEST.json`, find the selected pattern's line range, and read only those lines from `references/KB_Rhythm_Pacing.md`.
4. Using **IDX-3D**, identify needed emotions. Then use **Manifest-Based Loading Protocol**: look up `KB_Micro_Performance` in `references/KB_MASTER_MANIFEST.json`, find each needed emotion's line range, and read only those lines from `references/KB_Micro_Performance.md`.
5. Read `references/KB_Dialogue_Pacing.md` in full (57 lines).
6. Read `references/KB_Cinematic_Transitions.md` in full (72 lines).
7. Write the `## 分段 X Seedance 2.0 视频提示词`.
8. Internally perform dialogue word-count audit. **This audit is internal only and MUST NOT appear in user-facing output.**

**KB Read Summary**: 2 full small files + targeted reads from 4 large files (using the already-loaded unified manifest).

**STOP. Do not proceed to Step 4 until the video prompt is complete.**

---

### **Step 4: High-Energy Moment (HTM) Integration (Conditional)**

**Goal**: If triggered, generate a specialized HTM video prompt.

**Execution**:
1. Scan script and `分镜计划` for HTM trigger keywords (see **IDX-4A**).
2. If triggered:
   - Read `references/KB_Frozen_Moment.md` for full HTM creation guide.
   - Using **IDX-4B**, identify needed VFX categories. Then use **Manifest-Based Loading Protocol**: look up `KB_Combat_VFX` in `references/KB_MASTER_MANIFEST.json`, find each needed VFX category's line range, and read only those lines from `references/KB_Combat_VFX.md`.
   - Generate the `## 高燃时刻` block.
3. If not triggered, skip entirely.

---

## Core Constraints

1. **Mandatory Full Asset Referencing**: Enforced in Step 2 & 3. Asset names in `资产映射表` and all `[资产名]` tags MUST use the user's system language.
2. **Strict Dialogue Pacing Control**: Enforced in Step 3.
3. **Structured Bilingual Prompt**: Enforced in Step 2.
4. **Artistic Vision First**: Enforced in Step 1.
5. **Audio-Visual Block Structure**: Enforced in Step 3.
6. **Micro-Performance is Mandatory**: Enforced in Step 3.
7. **15-Second Segmentation**: The 4-step workflow applies to each 15-second segment.
8. **Prompt Character Limits**: 9-Grid <= 3800 chars; Seedance 2.0 <= 1000 chars.
9. **Camera Prompt Keywords Hidden**: Full English keywords used in 9-grid `STYLE:` line; public `电影技术规格` shows only model names.
10. **Sound as Compressed Annotation**: Every time segment MUST have `音效:` line.
11. **No Subtitles or Text**: 9-grid MUST NOT contain text. Video prompt starts with `No subtitles.` + `参考[九宫格]进行剧情延展`.
12. **"Keyframe Still" Principle**: 9-grid frames are frozen moments, no motion blur.
13. **6-Dimensional Continuity**: Character, Scene, Lighting, Narrative, Cinematography, Spatial Blocking consistent across 9 frames.
14. **Grid Position Labeling**: 9-grid 中每帧 MUST 以 `N(Grid-Pos):` 开头（如 `1(Top-L):`），确保图像模型正确排列网格位置。
15. **Per-Frame Lens & Lighting**: 9-grid 中每帧 MUST 包含独立的镜头参数 `[景别, 角度, 焦距, 光圈]` 和独立的灯光行 `[灯光类型], Ratio [比值], [色温关键词], [灯光补充]`。
16. **Structured FG/MG/BG**: 9-grid 中每帧的 FG/MG/BG 描述 MUST 各占独立一行，FG和MG以分号结尾，BG以句号结尾。
17. All other inherited constraints (aspect ratio, VO preservation, inter-segment transitions, bracketed asset referencing, etc.) remain active.
18. **Color System Integration**: Step 1 MUST 确定色温基准+饱和度+色彩基调，写入`色彩与风格`。STYLE 行 MUST 包含色彩基调+饱和度关键词（全局），每帧灯光行 MUST 包含色温关键词（逐帧）。

---

## Output Format (Strictly Adhere)

The final output MUST be a single Markdown document, strictly following this clean format:

```markdown
# Storyboard to Video - [Project Name]

**总时长**: [Total Duration] | **分段数**: [Segment Count] | **画幅**: [Aspect Ratio] | **视频类型**: [叙事/电商]

---

## 电影技术规格

### 相机与镜头
- [Camera Model] + [Lens Model]

### 色彩与风格
- **色温**: [色温范围] ([English keyword])
- **饱和度**: [等级] ([English keyword])
- **色彩基调**: [基调类型] ([English keyword])
- **补充说明**: [自由描述，如“冷蓝色调为主，暖黄路灯作为对比色”]

### 艺术愿景
- **叙事弧光**: [Selected Narrative Pattern]
- **剪辑风格**: [Selected Editing Style]
- **声音基调**: [Overall sound design direction]

---

## 资产映射表

| 资产名称 | 资产类型 | 参考图文件 |
|:---|:---|:---|
| [资产名称1] | [角色/场景/道具] | `1.png` |

---

## 分段 1 分镜计划 (0-15s)

**叙事功能**: [Segment's story purpose]

| 帧 | 景别 | 角度 | 叙事节拍 | 空间站位 | 关键元素 |
|:---|:-----|:-----|:---------|:---------|:---------|
| 1  | [Shot]| [Angle]| ...      | [初始站位] | [Description] |
| 2  | [Shot]| [Angle]| ...      | [继承帧1 / 位移+动机] | [Description] |

---

## 分段 1 九宫格分镜提示词

```
[画幅] format. 3x3 storyboard grid, seamless panels, no borders, no text, no subtitles. Time sequence of 9 frames for 15-second video.
STYLE: [相机型号], [镜头型号]. [画面质感关键词]. [色彩基调关键词], [饱和度关键词]. [场景美学].
---
1(Top-L): [景别, 角度, 焦距, 光圈]. [构图技法], [构图补充说明].
FG: [前景描述];
MG: [中景描述，含角色[资产名]+场景[资产名]+动作];
BG: [背景描述，含道具/产品[资产名]].
[灯光类型], Ratio [比值], [色温关键词], [灯光补充].

2(Top-C): [景别, 角度, 焦距, 光圈]. [构图技法], [构图补充说明].
FG: ...;
MG: ...;
BG: ...
[灯光类型], Ratio [比值], [色温关键词], [灯光补充].

3(Top-R): ...
4(Mid-L): ...
5(Mid-C): ...
6(Mid-R): ...
7(Bot-L): ...
8(Bot-C): ...
9(Bot-R): ...
---
NO TEXT. Identical character/scene/lighting across all panels. Cinematic film stills, photorealistic.
```

**九宫格帧结构规则（MUST遵守）**：
- **网格位置标签**: 每帧 MUST 以 `N(Grid-Pos):` 开头。映射表: 1=Top-L, 2=Top-C, 3=Top-R, 4=Mid-L, 5=Mid-C, 6=Mid-R, 7=Bot-L, 8=Bot-C, 9=Bot-R。
- **镜头参数块**: 紧跟位置标签，格式为 `[景别, 角度, 焦距, 光圈]`，焦距和光圈从 KB_Camera_Guide 中选取。
- **FG/MG/BG 独立行**: 每层描述 MUST 独占一行，以分号 `;` 结尾（BG以句号 `.` 结尾）。
- **独立灯光行**: 每帧末尾 MUST 有独立的灯光行，格式为 `[灯光类型], Ratio [比值], [色温关键词], [灯光补充].`，从 KB_Lighting_Atmosphere 中选取。
- **STYLE行色彩参数**: STYLE 行 MUST 包含 `[色彩基调关键词], [饱和度关键词]`，从 IDX-2D 中选取，作为全局色彩参数。
- **Header**: MUST 包含 `seamless panels, no borders` 和 `Time sequence of 9 frames for 15-second video`。
- **Footer**: MUST 以 `NO TEXT. Identical character/scene/lighting across all panels. Cinematic film stills, photorealistic.` 结尾。

---

## 分段 1 Seedance 2.0 视频提示词

(Video prompt block)

---

## 高燃时刻：[Name] (Conditional)

(HTM block if triggered)
```
