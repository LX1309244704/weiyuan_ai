---
name: KB_Cinematic_Camera_Guide
description: 提供电影摄影机、静照相机、胶片、镜头、焦距、光圈到其视觉特征关键词的全面映射。用于为融合式提示词提供专业的英文技术参数。
version: 2.0.0
---

# Knowledge Base: Cinematic Camera & Lens Guide

本知识库提供从摄影设备到视觉特征关键词的全面映射，用于为分镜提示词提供专业的英文技术参数。

## 1. Camera Bodies & Film Stocks (The "Look")

### 1.1 Cinema Cameras

| Model | Prompt Keywords (EN) |
| :--- | :--- |
| **ARRI Alexa 65** | `Soft highlight roll-off, natural skin tones, clean image, high dynamic range, Arri color science, modern cinema standard` |
| **Sony Venice 2** | `Sharp and cold tone, high contrast, modern digital look, rich shadow details, crisp clarity, dual base ISO clean look` |
| **RED Monstro 8K** | `Extreme sharpness, saturated colors, hard texture, hyper-realistic clarity, high contrast, weapon 8k sensor` |
| **IMAX 70mm** | `Incredible depth, fine grain, massive scale, immersive field of view, shallow depth of field, epic scale, 18k resolution` |
| **Panavision Panaflex** | `Warm vintage film look, soft film grain, golden age aesthetic, heavy color weight, rich texture, classic Hollywood` |
| **Arriflex 416 (16mm)** | `Heavy film grain, noise, soft edges, indie movie aesthetic, warm or greenish tint, raw texture, 16mm film look` |

### 1.2 Still Photography Cameras

| Camera | Prompt Keywords (EN) |
| :--- | :--- |
| **Canon EOS R5** | `Canon color science, healthy skin tones, creamy bokeh, soft defocus, vibrant but natural colors, studio portrait quality` |
| **Sony A7R IV** | `Razor sharp focus, extreme dynamic range, modern digital look, clinical clarity, high contrast, cool color temperature` |
| **Nikon D850** | `Rich textures, deep blacks, high fidelity, landscape photography master, realistic saturation, optical precision` |
| **Fujifilm GFX 100** | `Medium format depth, 3D pop, Fujifilm color simulation, incredibly detailed textures, soft highlight rolloff, atmospheric depth` |
| **Hasselblad H6D** | `Hasselblad Natural Color Solution (HNCS), premium studio look, lifelike tones, commercial editorial aesthetic, ultra-fine details` |
| **Leica M10** | `The Leica look, high micro-contrast, 3D separation, street photography vibe, rangefinder aesthetic, rich shadows` |
| **Polaroid SX-70** | `Instant film aesthetic, soft focus, chemical color shifts, vintage polaroid frame, nostalgic haze, low contrast` |
| **GoPro Hero 11** | `Fisheye distortion, ultra-wide FOV, deep depth of field, action camera look, dynamic motion blur, immersive view` |

### 1.3 Film Stocks (Emulsion)

| Stock | Prompt Keywords (EN) |
| :--- | :--- |
| **Kodak Portra 400** | `Warm yellow tones, Japanese photography style, nostalgic vibe, natural colors, fine grain, skin tone warmth` |
| **Kodak Vision3 500T** | `Blue tungsten tone, cool cinematic look, king of night scenes, teal and orange vibe, halation` |
| **Cinestill 800T** | `Red halation around lights, neon glow, cyberpunk aesthetic, bloom effect, vintage night photography` |

## 2. Lens Characteristics (The "Character")

| Lens Model | Prompt Keywords (EN) |
| :--- | :--- |
| **Panavision C-Series** | `Anamorphic blue lens flare, horizontal streaks, oval bokeh, sci-fi aesthetic, cinematic aspect ratio` |
| **Cooke Anamorphic** | `The Cooke Look, warm and oily texture, creamy fall-off, gentle contrast, flattering skin tones` |
| **ARRI Master Primes** | `Clinically sharp, zero distortion, perfect optical precision, architectural lines, clean edges, neutral color` |
| **Angenieux Optimo** | `Warm cinematic look, human skin tones, organic contrast, balanced sharpness, Hollywood blockbuster look` |
| **Leica Noctilux** | `Dreamy creamy bokeh, melting background, artistic isolation, f/0.95 aesthetic, bokeh-heavy rendering` |
| **Canon K35** | `Dreamy glow, bloom highlights, low contrast, vintage aesthetic, ethereal atmosphere, highlight halo` |
| **Canon Dream Lens** | `Ethereal glow, heavy bloom, painterly bokeh, soft edges, dreamlike atmosphere, "The Dream Lens" look` |
| **Zeiss Super Speed** | `Triangle bokeh, triangular highlights, cold coating, vintage sharpness, The Shining aesthetic, atmospheric flare` |
| **Helios 44-2** | `Swirly bokeh, vortex background blur, sharp center with soft edges, vintage spherical aberration` |
| **Super Takumar 50mm** | `Radioactive yellow cast, warm golden flare, rainbow ghosting, vintage film look, soft but sharp rendering` |
| **Petzval 85 Art** | `Tunnel vision effect, extreme radial blur, focus strictly in center, artistic distortion, swirling background` |
| **Holga 120N** | `Plastic lens aesthetic, heavy vignetting, light leaks, chromatic aberration, blurred edges, lo-fi photography` |
| **Lensbaby Composer** | `Miniature effect, tilt-shift focus, slice of focus, blurred top and bottom, toy city look, creative focus isolation` |

## 3. Focal Length (Perspective)

| Range | Prompt Keywords (EN) |
| :--- | :--- |
| **14mm - 16mm** | `Ultra wide angle, distorted perspective, grand scale, dynamic angle, exaggerated foreground, background compression` |
| **24mm - 35mm** | `Wide angle, environmental context, establishing shot, street photography perspective, contextual framing` |
| **50mm** | `Human eye perspective, realistic proportions, standard lens, natural composition, psychological distance` |
| **85mm** | `Portrait lens, flattering compression, subject isolation, slight background compression, separation from environment` |
| **100mm+** | `Telephoto compression, flattened perspective, macro details, extreme close-up, background isolation, micro details` |

## 4. Aperture (Depth of Field)

| f-stop Range | Prompt Keywords (EN) |
| :--- | :--- |
| **f/0.95 - f/1.4** | `Razor thin depth of field, background melted, dreamy blur, bokeh heavy, subject pop, extreme separation` |
| **f/1.8 - f/2.8** | `Cinematic separation, subject sharp, background recognizable but soft, 3D pop, emotional isolation` |
| **f/4.0 - f/5.6** | `Balanced focus, environmental portrait, medium depth of field, contextual sharpness, storytelling depth` |
| **f/8.0 - f/11** | `Deep focus, everything in focus, high detail background, comprehensive sharpness, layered clarity` |
| **f/16 - f/22** | `Diffraction starbursts, infinite depth of field, sharp horizon, edge-to-edge detail, optical diffraction patterns` |
