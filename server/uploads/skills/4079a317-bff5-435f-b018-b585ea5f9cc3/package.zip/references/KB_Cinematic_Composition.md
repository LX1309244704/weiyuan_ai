---
name: KB_Cinematic_Composition
description: 电影构图知识库，提供7大基础构图技巧、镜头角度、景别分类的全面映射。用于为AI视频生成和分镜设计提供专业的构图参数和提示词。运镜相关内容请参考 KB_Camera_Choreography.md。
version: 1.2.0
---

# Knowledge Base: Cinematic Composition Guide

本知识库整合了电影构图的核心方法论，包括7大基础构图技巧、镜头角度，以及构图选择决策指南。

> **注意**：运镜相关内容请参考独立的 `KB_Camera_Choreography.md` 知识库。

---

## 1. 基础构图技巧 (Composition Techniques)

### 1.1 中心构图 (Center Composition)

| 属性 | 说明 |
| :--- | :--- |
| **使用频率** | 电影中约10%-15% |
| **核心特点** | 将主体放在画面绝对中心 |
| **视觉效果** | 稳定感、突出主体、带入角色内心世界 |
| **适用场景** | 特写镜头、强调情绪、表现宿命感 |
| **注意事项** | 容易显得呆板，需搭配合适的景别 |
| **经典案例** | 《奥本海默》《2001太空漫游》 |
| **EN Prompts** | `center composition, subject centered in frame, symmetrical framing, focal point at center` |
| **CN 提示词** | 使用中心构图，将[主体]放在画面中心 |

### 1.2 对称构图 (Symmetrical Composition)

| 属性 | 说明 |
| :--- | :--- |
| **使用频率** | 电影中约10% |
| **核心特点** | 画面左右或上下完全对称 |
| **视觉效果** | 秩序感、庄严感、视觉舒适 |
| **适用场景** | 表现权力、庄重、建筑、仪式感 |
| **代表导演** | 韦斯·安德森 (Wes Anderson) |
| **经典案例** | 《布达佩斯大饭店》《闪灵》 |
| **EN Prompts** | `symmetrical composition, perfect symmetry, mirror image framing, Wes Anderson style, balanced frame` |
| **CN 提示词** | 使用对称构图，将[主体]放于画面中心，左右完全对称 |

### 1.3 三分法构图 (Rule of Thirds)

| 属性 | 说明 |
| :--- | :--- |
| **使用频率** | 电影中50%以上（最常用） |
| **核心特点** | 画面用线平均分成九宫格，主体放在线上或交叉点 |
| **视觉效果** | 留白感、延伸感、呼吸感、轻松自然 |
| **适用场景** | 万能搭配，适用于远景、中景、特写 |
| **优势** | 不会出错的安全选择 |
| **经典案例** | 几乎所有电影都大量使用 |
| **EN Prompts** | `rule of thirds, subject placed on third line, off-center composition, balanced negative space, thirds grid alignment` |
| **CN 提示词** | 使用三分线构图，[主体]放在三分之一处 |

### 1.4 对角线构图 (Diagonal Composition)

| 属性 | 说明 |
| :--- | :--- |
| **使用频率** | 电影中约10%-15% |
| **核心特点** | 画面元素沿对角线排列或分割 |
| **视觉效果** | 线条美感、大片感、视觉冲击力强、动感 |
| **适用场景** | 运动画面、登山、爬楼梯、光影分割 |
| **进阶技巧** | 搭配环绕运镜提升视觉冲击力 |
| **经典案例** | 《巴比伦》《盗梦空间》 |
| **EN Prompts** | `diagonal composition, dynamic diagonal lines, slanted framing, diagonal visual flow, dramatic angle` |
| **CN 提示词** | 使用对角线构图，[元素]沿对角线排列 |

### 1.5 引导线构图 (Leading Lines Composition)

| 属性 | 说明 |
| :--- | :--- |
| **使用频率** | 电影中约10% |
| **核心特点** | 利用场景中的线条引导观众注意力 |
| **视觉效果** | 强引导性、线条美感、高级感、电影感 |
| **常见引导线** | 道路、栅栏、建筑物、马路、蜿蜒山路、走廊、铁轨 |
| **适用场景** | 旅行拍摄、公路行车、建筑空间 |
| **经典案例** | 《肖申克的救赎》《银翼杀手2049》 |
| **EN Prompts** | `leading lines composition, converging lines, vanishing point, perspective lines guiding to subject, linear visual path` |
| **CN 提示词** | 指定[元素]作为引导线，从远处向近处延伸，引导视线至[主体] |

### 1.6 框架式构图 (Frame within Frame)

| 属性 | 说明 |
| :--- | :--- |
| **使用频率** | 电影中约5% |
| **核心特点** | 用场景中的框架元素框住主体 |
| **视觉效果** | 凸显内心情绪、表现处境、窥视感、紧张感 |
| **常见框架** | 车窗、门框、窗户、拱门、镜子、树枝 |
| **情感表达** | 抑郁、压抑、孤独、被困 |
| **经典案例** | 《小丑》《搜索者》《后窗》 |
| **EN Prompts** | `frame within frame, natural framing, doorway framing, window frame composition, nested frame, voyeuristic framing` |
| **CN 提示词** | 使用[框架元素]作为框架来构图，将[主体]框在其中 |

### 1.7 前景构图 / 脏构图 (Foreground Composition / Dirty Shot)

| 属性 | 说明 |
| :--- | :--- |
| **使用频率** | 电影中常见 |
| **核心特点** | 在主体前方加入前景遮挡元素 |
| **视觉效果** | 空间纵深感、沉浸感、故事感、电影感 |
| **情感表达** | 还原当事人或第三者视角，增强情绪带入 |
| **常见前景** | 人物肩膀、酒杯、植物、行人、建筑边缘 |
| **经典案例** | 《重庆森林》《教父》 |
| **EN Prompts** | `foreground element, dirty shot, over-the-shoulder framing, depth layering, foreground bokeh, environmental depth` |
| **CN 提示词** | 使用前景构图，让[元素]作为前景，[主体]在中景或背景 |

---

## 2. 镜头角度 (Camera Angles)

### 2.1 基础镜头角度

| 角度类型 | 视觉效果 | 适用场景 | EN Prompts |
| :--- | :--- | :--- | :--- |
| **平视镜头 (Eye Level)** | 中立、客观、自然 | 对话场景、日常叙事 | `eye level shot, neutral angle, natural perspective` |
| **低角度 (Low Angle)** | 权威感、威胁感、英雄感 | 表现强大、恐惧、崇敬 | `low angle shot, looking up, heroic angle, powerful perspective` |
| **高角度 (High Angle)** | 渺小感、脆弱感、俯瞰 | 表现弱势、孤独、全局 | `high angle shot, looking down, bird's eye view, vulnerable perspective` |
| **荷兰角 (Dutch Angle)** | 不安、紧张、疯狂 | 心理扭曲、悬疑、恐怖 | `Dutch angle, tilted frame, canted angle, disorienting tilt` |
| **俯拍 (Overhead Shot)** | 上帝视角、全局观 | 展示空间布局、舞蹈 | `overhead shot, top-down view, God's eye view, aerial perspective` |
| **仰拍 (Worm's Eye)** | 极端渺小感、戏剧性 | 建筑、巨物、极端情绪 | `worm's eye view, extreme low angle, ground level looking up` |

### 2.2 特殊镜头高度

| 高度类型 | 视觉效果 | 适用场景 | EN Prompts |
| :--- | :--- | :--- | :--- |
| **肩高镜头 (Shoulder Level)** | 标准电影感、专业 | 大多数对话和叙事 | `shoulder level shot, cinematic height, standard film angle` |
| **牛仔镜头 (Cowboy Shot)** | 腰部以上、西部片风格 | 动作、枪战、对峙 | `cowboy shot, hip level, American shot, mid-thigh framing` |
| **膝高镜头 (Knee Level)** | 轻微仰视、动态感 | 行走、潜行、追逐 | `knee level shot, low perspective, dynamic low angle` |
| **地面镜头 (Ground Level)** | 极端视角、神秘感 | 脚步、悬疑、动物视角 | `ground level shot, floor perspective, ant's eye view` |

---

## 3. 景别分类 (Shot Sizes)

### 3.1 景别总览

| 景别 | 英文名称 | 画面范围 | 主要用途 | EN Prompts |
| :--- | :--- | :--- | :--- | :--- |
| **大远景** | Extreme Wide Shot (EWS) | 广阔环境，人物极小 | 建立场景、史诗感 | `extreme wide shot, establishing shot, vast landscape` |
| **远景** | Wide Shot (WS) | 全身+大量环境 | 场景建立、空间关系 | `wide shot, long shot, full body with environment` |
| **全景** | Full Shot (FS) | 人物全身 | 展示动作、服装 | `full shot, full body shot, head to toe framing` |
| **中景** | Medium Shot (MS) | 腰部以上 | 对话、日常叙事 | `medium shot, waist-up framing, conversational shot` |
| **中近景** | Medium Close-Up (MCU) | 胸部以上 | 情感表达、对话 | `medium close-up, chest-up framing, emotional shot` |
| **近景** | Close-Up (CU) | 脸部/物体细节 | 情绪、反应、重要物品 | `close-up shot, face filling frame, detail shot` |
| **特写** | Extreme Close-Up (ECU) | 眼睛/嘴唇/细节 | 极端情绪、关键细节 | `extreme close-up, macro shot, eyes only` |

### 3.2 特殊景别

| 景别类型 | 画面特点 | 适用场景 | EN Prompts |
| :--- | :--- | :--- | :--- |
| **过肩镜头 (OTS)** | 从一人肩后拍另一人 | 对话、对峙 | `over-the-shoulder shot, OTS shot, conversation framing` |
| **双人镜头 (Two Shot)** | 两人同框 | 对话、浪漫、对峙 | `two shot, dual subject framing, couple shot` |
| **主观镜头 (POV)** | 角色视角 | 悬疑、恐怖、第一人称 | `POV shot, point of view, first person perspective` |
| **插入镜头 (Insert)** | 物品/细节特写 | 道具、手部动作 | `insert shot, cutaway detail, object close-up` |

---

## 4. 构图选择决策树 (Composition Decision Guide)

### 4.1 按情感需求选择

| 情感目标 | 推荐构图 | 推荐角度 | 推荐景别 |
| :--- | :--- | :--- | :--- |
| **稳定、庄重** | 中心构图、对称构图 | 平视 | 中景、全景 |
| **轻松、自然** | 三分法 | 平视、肩高 | 中景、中近景 |
| **紧张、不安** | 对角线、框架式 | 荷兰角、低角度 | 近景、特写 |
| **史诗、宏大** | 引导线、对称 | 高角度、俯拍 | 大远景、远景 |
| **亲密、情感** | 前景构图、中心 | 平视、低角度 | 中近景、近景 |
| **孤独、疏离** | 框架式、大量留白 | 高角度 | 远景、大远景 |

### 4.2 按场景类型选择

| 场景类型 | 推荐构图组合 | 推荐景别 |
| :--- | :--- | :--- |
| **对话场景** | 三分法 + 过肩镜头 + 平视 | 中景、中近景 |
| **动作场景** | 对角线 + 低角度 | 全景、中景 |
| **建筑/空间** | 对称 + 引导线 | 远景、大远景 |
| **人物特写** | 中心构图 + 平视 | 近景、特写 |
| **追逐场景** | 对角线 + 低角度 | 中景、全景 |
| **情绪转折** | 中心构图 | 近景、特写 |
| **开场建立** | 引导线 | 大远景、远景 |

---

## 5. 经典电影构图参考 (Classic Film References)

| 电影 | 导演 | 标志性构图风格 |
| :--- | :--- | :--- |
| 《布达佩斯大饭店》 | 韦斯·安德森 | 极致对称、糖果色调 |
| 《闪灵》 | 斯坦利·库布里克 | 对称、单点透视、长走廊 |
| 《银翼杀手2049》 | 丹尼斯·维伦纽瓦 | 极简构图、大量留白 |
| 《教父》 | 弗朗西斯·科波拉 | 低调光线、框架构图 |
| 《奥本海默》 | 克里斯托弗·诺兰 | 中心特写、IMAX大画幅 |
| 《重庆森林》 | 王家卫 | 前景遮挡、手持、框架 |
| 《盗梦空间》 | 克里斯托弗·诺兰 | 对角线、空间扭曲 |
| 《1917》 | 萨姆·门德斯 | 长镜头、跟拍、沉浸式 |

---

## 6. 构图提示词速查表 (Quick Reference)

| 构图类型 | 英文提示词 |
| :--- | :--- |
| 中心构图 | `center composition, centered framing, subject at center` |
| 对称构图 | `symmetrical composition, perfect symmetry, mirror framing` |
| 三分法 | `rule of thirds, thirds grid, off-center placement` |
| 对角线 | `diagonal composition, dynamic diagonals, slanted lines` |
| 引导线 | `leading lines, converging lines, vanishing point` |
| 框架式 | `frame within frame, natural framing, nested frame` |
| 前景构图 | `foreground element, dirty shot, depth layering` |

---

## 7. 构图常见错误 (Common Mistakes)

| 错误类型 | 问题描述 | 解决方案 |
| :--- | :--- | :--- |
| **构图冲突** | 同时使用矛盾的构图指令 | 保持构图风格一致 |
| **过度复杂** | 一个镜头塞入太多元素 | 简化，突出一个重点 |
| **模糊描述** | 使用"好看""有趣"等模糊词 | 使用具体的技术术语 |
| **景别不当** | 景别与情感不匹配 | 参考决策树选择 |

---

## 8. 核心理念 (Core Philosophy)

> **构图方式没有好与坏，只有适合与不适合。能够把情绪、氛围表达到位的构图，就是好的构图。**

- 构图服务于叙事，不是为了炫技
- 每种构图都有其情感暗示
- 打破规则前，先理解规则
- 观察经典电影，学习大师手法
- 实践是最好的老师

