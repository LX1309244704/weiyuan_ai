---
name: KB_Combat_VFX
description: 提供战斗/动作场景中使用的VFX（视觉特效）关键词的权威清单，涵盖9大分类101个关键词，并包含高燃时刻的VFX使用规则和高冲击力动作动词。
version: 1.0.0
---

# 战斗/动作场景 VFX 特效关键词清单

> 基于 ActionVFX 专业分类体系、电影VFX工业标准整理。
> 所有英文关键词均为 AI 视频模型可直接识别的提示词。

---

## 一、分类总览

| 编号 | 分类 | 关键词数量 | 适用场景 |
|:---|:---|:---|:---|
| 1 | 冲击与碎片 (Impact & Debris) | 15 | 拳脚交锋、爆炸、碰撞 |
| 2 | 火焰与爆炸 (Fire & Explosions) | 12 | 爆破、燃烧、火焰武器 |
| 3 | 烟雾与大气 (Smoke & Atmosphere) | 14 | 战场氛围、环境渲染 |
| 4 | 火花与电弧 (Sparks & Electricity) | 10 | 金属碰撞、电力系统、科幻能量 |
| 5 | 水与天气 (Water & Weather) | 12 | 雨战、海战、暴风雪 |
| 6 | 能量与魔法 (Energy & Magic) | 10 | 科幻、超能力、奇幻 |
| 7 | 物理反馈 (Physical Feedback) | 12 | 身体反应、环境反馈、材质变形 |
| 8 | 速度与时间 (Speed & Time) | 8 | 变速、慢动作、子弹时间 |
| 9 | 光效与镜头 (Optics & Lens FX) | 8 | 光学特效、镜头效果 |
| **合计** | | **101** | |

---

## 二、详细清单

### 1. 冲击与碎片 (Impact & Debris)

| 英文关键词 | 中文描述 | 视觉效果 | 典型场景 |
|:---|:---|:---|:---|
| debris scatter | 碎片飞溅 | 物体碎裂后碎片四散 | 拳击命中、墙体撞击 |
| debris flying | 碎片飞散 | 碎片在空中飞舞 | 爆炸余波、建筑崩塌 |
| dust clouds bloom | 尘云绽放 | 冲击产生蘑菇状尘云 | 重物落地、建筑倒塌 |
| impact crater | 冲击坑 | 地面出现凹陷裂纹 | 超级英雄落地、重击 |
| concrete cracking | 混凝土龟裂 | 地面/墙面出现裂纹扩散 | 重击地面、震波传导 |
| glass shattering | 玻璃碎裂 | 玻璃爆裂成碎片飞散 | 窗户击碎、瓶子破碎 |
| wood splintering | 木材碎裂 | 木质物体断裂飞溅 | 门被踢开、家具碎裂 |
| wall crumbling | 墙体崩塌 | 墙壁碎裂倒塌 | 穿墙、爆炸冲击 |
| building collapse | 建筑倒塌 | 整体结构坍塌 | 大规模破坏场景 |
| rebar snapping | 钢筋断裂 | 金属断裂弹出 | 桥梁/建筑崩塌 |
| papers flutter | 纸张飘散 | 纸张在气流中飞舞 | 办公室爆炸、冲击波 |
| falling burning debris | 坠落燃烧碎片 | 带火的碎片从空中坠落 | 火灾、爆炸后 |
| exploding wood debris | 爆炸木质碎片 | 木质结构爆裂飞散 | 木门/木箱爆炸 |
| ground crack spreading | 地面裂纹扩散 | 裂纹从冲击点向外扩散 | 超能力释放、重击 |
| shrapnel spray | 弹片喷射 | 金属碎片高速飞出 | 爆炸、金属破碎 |

### 2. 火焰与爆炸 (Fire & Explosions)

| 英文关键词 | 中文描述 | 视觉效果 | 典型场景 |
|:---|:---|:---|:---|
| explosion | 爆炸 | 火球+冲击波+碎片 | 炸弹、车辆爆炸 |
| directional explosion | 定向爆炸 | 单方向的爆炸效果 | 导弹命中、定向爆破 |
| fire burst | 火焰爆发 | 突然喷出的火焰 | 燃料泄漏点燃 |
| fireball | 火球 | 球形火焰扩散 | 大规模爆炸 |
| building fire | 建筑火灾 | 建筑物燃烧 | 火灾场景 |
| body fire | 身体着火 | 人物身上燃烧 | 火焰攻击 |
| lava glows | 熔岩发光 | 熔岩的橙红色发光 | 火山、地狱场景 |
| embers swirl | 火星旋转 | 火星在空中旋转飘浮 | 火灾余烬、锻造 |
| embers floating | 漂浮火星 | 火星缓慢上升飘浮 | 篝火、废墟 |
| falling ash | 飘落灰烬 | 灰烬从空中缓慢飘落 | 火灾后、火山灰 |
| molotov cocktail explosion | 燃烧瓶爆炸 | 玻璃碎裂+液体燃烧扩散 | 街头冲突 |
| heat distortion | 热浪扭曲 | 高温导致空气折射扭曲 | 爆炸附近、沙漠 |

### 3. 烟雾与大气 (Smoke & Atmosphere)

| 英文关键词 | 中文描述 | 视觉效果 | 典型场景 |
|:---|:---|:---|:---|
| smoke haze | 烟雾弥漫 | 弥散的轻烟笼罩场景 | 战场、火灾后 |
| smoke plumes | 烟柱 | 垂直上升的浓烟 | 爆炸后、火灾 |
| explosion smoke | 爆炸烟雾 | 爆炸产生的浓密烟雾 | 爆炸瞬间 |
| displaced fog | 位移雾气 | 被冲击波推开的雾气 | 冲击波经过 |
| dust particles in the air | 空气中的尘埃粒子 | 微小粒子在光线中可见 | 废墟、仓库 |
| dust motes | 尘埃微粒 | 光束中可见的漂浮微粒 | 室内光线、废弃空间 |
| dust and sun shafts | 尘埃与光束 | 丁达尔效应，光束穿过尘埃 | 破损建筑、森林 |
| large scale dust waves | 大规模尘浪 | 巨大的尘土波浪推进 | 建筑倒塌、沙暴 |
| steam rising | 蒸汽升腾 | 蒸汽从表面上升 | 雨后热地面、下水道 |
| steam plumes | 蒸汽柱 | 蒸汽喷射形成的柱状 | 管道破裂、工业场景 |
| breath condensation | 呼吸凝结 | 呼出的气体在冷空气中可见 | 寒冷环境 |
| incense smoke curls | 烟雾缭绕 | 细长烟雾缓慢卷曲上升 | 寺庙、道场 |
| fog rolling | 雾气翻滚 | 浓雾在地面缓慢流动 | 恐怖、神秘场景 |
| ash plumes | 灰烬柱 | 灰烬形成的上升气柱 | 火山、大火 |

### 4. 火花与电弧 (Sparks & Electricity)

| 英文关键词 | 中文描述 | 视觉效果 | 典型场景 |
|:---|:---|:---|:---|
| sparks | 火花 | 金属碰撞产生的火花 | 刀剑交锋、金属摩擦 |
| sparks shower | 火花飞溅 | 大量火花如瀑布般飞溅 | 焊接、金属切割 |
| sparks when scraping | 刮擦火花 | 物体摩擦地面的火花 | 摩托车/车辆侧滑 |
| spark ricochet hits | 火花弹跳击中 | 火花从撞击点弹射 | 子弹击中金属 |
| electric arcs | 电弧 | 电流在两点间跳跃 | 电力系统、科幻武器 |
| electricity crackling | 电流噼啪 | 电流在表面跳动 | 电击、能量过载 |
| welding sparks | 焊接火花 | 焊接时产生的火花 | 工业场景 |
| muzzle flashes | 枪口闪光 | 开枪时枪口的闪光 | 枪战 |
| muzzle flashes strobe | 枪口闪光频闪 | 连续射击的频闪效果 | 激烈枪战 |
| ionized light | 电离光 | 蓝紫色的电离发光 | 科幻能量释放 |

### 5. 水与天气 (Water & Weather)

| 英文关键词 | 中文描述 | 视觉效果 | 典型场景 |
|:---|:---|:---|:---|
| rain on lens | 镜头雨滴 | 雨滴打在镜头上 | 雨中战斗 |
| rain streaks | 雨丝 | 可见的雨丝线条 | 暴雨场景 |
| wet lens splashes | 湿镜头溅射 | 水溅到镜头上 | 近距离水花 |
| water spray | 水花喷溅 | 水被击打后飞溅 | 水面战斗、船只 |
| water droplets suspended | 悬浮水滴 | 慢动作中水滴悬浮 | 子弹时间+雨 |
| waves smash rocks | 海浪拍打岩石 | 巨浪撞击产生水花 | 海边战斗 |
| snow drifting | 雪花飘落 | 雪花在空中飘舞 | 雪地战斗 |
| powder spray | 粉雪喷溅 | 雪地被踩踏/冲击后喷起 | 雪地追逐 |
| lightning silhouettes | 闪电剪影 | 闪电照亮人物形成剪影 | 暴风雨战斗 |
| rotor wash kicks debris | 旋翼气流卷起碎片 | 直升机气流吹起碎片 | 直升机场景 |
| heat shimmer | 热浪扭曲 | 高温空气折射效果 | 沙漠、爆炸附近 |
| frost forming | 霜冻形成 | 表面快速结霜 | 冰系能力、极寒 |

### 6. 能量与魔法 (Energy & Magic)

| 英文关键词 | 中文描述 | 视觉效果 | 典型场景 |
|:---|:---|:---|:---|
| energy burst | 能量爆发 | 从中心向外扩散的能量波 | 超能力释放 |
| shockwave rippling | 冲击波扩散 | 可见的空气冲击波环 | 爆炸、超音速、重击 |
| pulsing heatwave | 脉冲热浪 | 周期性的热浪扭曲 | 能量蓄力、释放 |
| energy shield | 能量护盾 | 半透明的防护罩 | 科幻防御 |
| light streaks | 光线条纹 | 高速移动的光线拖尾 | 能量攻击、激光 |
| aura glow | 气场发光 | 人物周围的光晕 | 觉醒、变身 |
| portal opening | 传送门开启 | 空间撕裂/旋转的门 | 奇幻、科幻 |
| energy tendrils | 能量触须 | 从源头延伸的能量丝 | 魔法、暗黑能量 |
| disintegration | 粒子化消散 | 物体分解为粒子消散 | 灭霸响指、能量武器 |
| air distortion | 空气扭曲 | 力场导致的空气折射 | 隐形、能量场 |

### 7. 物理反馈 (Physical Feedback)

| 英文关键词 | 中文描述 | 视觉效果 | 典型场景 |
|:---|:---|:---|:---|
| cloth fluttering | 布料翻飞 | 衣物/披风被气流吹动 | 冲击波、高速移动 |
| hair whipping | 头发飘散 | 头发被气流吹起 | 冲击波、转身 |
| ground trembling | 地面震颤 | 地面微微颤动 | 重物落地、爆炸 |
| banners whip | 旗帜翻飞 | 旗帜被风/冲击波吹动 | 战场、冲击波 |
| sweat highlights | 汗珠高光 | 汗水在光线下闪烁 | 激烈格斗 |
| blood splatter | 血液飞溅 | 血液从伤口飞出 | 格斗受伤 |
| fabric tearing | 布料撕裂 | 衣物被撕破 | 近身格斗 |
| metal deformation | 金属变形 | 金属被力量弯曲/凹陷 | 超能力、重击 |
| rope snapping | 绳索断裂 | 绳索被拉断弹开 | 束缚挣脱 |
| oil splash | 油液飞溅 | 油脂/液体被击打飞溅 | 厨房战斗、机械破坏 |
| broken tiles | 碎裂瓷砖 | 瓷砖碎裂飞溅 | 室内格斗 |
| straps snap | 绑带断裂 | 固定带突然断开 | 货物散落、挣脱 |

### 8. 速度与时间 (Speed & Time)

| 英文关键词 | 中文描述 | 视觉效果 | 典型场景 |
|:---|:---|:---|:---|
| slow motion | 慢动作 | 时间减速 | 关键打击瞬间 |
| bullet time | 子弹时间 | 极慢+环绕镜头 | 闪避、关键一击 |
| speed ramp | 变速 | 慢→快或快→慢的速度变化 | 动作节奏控制 |
| time freeze | 时间冻结 | 完全静止 | 凝固瞬间 |
| motion blur | 动态模糊 | 高速运动的模糊拖尾 | 快速出拳/踢腿 |
| afterimage / ghost trail | 残影/幽灵拖尾 | 运动轨迹上的半透明残影 | 极速移动 |
| foreground rush | 前景冲刺 | 物体快速掠过镜头前方 | 战斗中的碎片/人物 |
| high shutter for crisp debris | 高快门清晰碎片 | 碎片在高速中保持清晰 | 爆炸慢放 |

### 9. 光效与镜头 (Optics & Lens FX)

| 英文关键词 | 中文描述 | 视觉效果 | 典型场景 |
|:---|:---|:---|:---|
| lens flare | 镜头光晕 | 强光源产生的光晕 | 爆炸闪光、阳光 |
| emergency strobes | 紧急频闪灯 | 红蓝交替的频闪光 | 警车、紧急场景 |
| red flares pierce fog | 信号弹穿透雾气 | 红色光源穿过雾气 | 军事、求救 |
| spotlight sweeps | 聚光灯扫射 | 聚光灯在场景中扫过 | 搜索、监狱 |
| neon reflections | 霓虹反射 | 霓虹灯在湿面上的反射 | 赛博朋克战斗 |
| impact frame flash white | 冲击帧闪白 | 打击瞬间画面闪白 | 关键一击 |
| cinematic teal-and-orange | 电影级青橙色调 | 经典动作片色彩分级 | 所有动作场景 |
| high-contrast noir | 高对比黑色电影 | 极端明暗对比 | 暗巷格斗、悬疑 |

---

## 三、高燃时刻 VFX 使用规则

### 3.1 T=0 帧（凝固瞬间）必须包含的 VFX

凝固瞬间（T=0）是整个高燃时刻的视觉高潮，必须包含至少 **2种不同分类** 的VFX关键词：

| 组合示例 | 分类覆盖 |
|:---|:---|
| sparks shower + dust clouds bloom | 火花 + 烟雾 |
| glass shattering + shockwave rippling | 碎片 + 能量 |
| energy burst + cloth fluttering | 能量 + 物理反馈 |
| explosion + debris scatter + motion blur | 爆炸 + 碎片 + 速度 |

### 3.2 因果时间线 VFX 分配建议

| 时间阶段 | 帧 | VFX 密度 | 推荐分类 |
|:---|:---|:---|:---|
| 蓄力 (T-4 至 T-2) | 帧1-3 | 低 → 中 | 大气类（dust motes, breath condensation）、物理反馈（cloth fluttering） |
| 触发 (T-1) | 帧4 | 中 | 速度类（motion blur, foreground rush）、光效（lens flare） |
| **凝固瞬间 (T=0)** | **帧5** | **最高** | **冲击+火花+能量+速度（至少2类）** |
| 冲击 (T+1) | 帧6 | 高 | 爆炸类、碎片类、冲击波 |
| 余波 (T+2 至 T+3) | 帧7-8 | 中 → 低 | 烟雾类（smoke plumes, dust settling）、物理反馈（debris falling） |
| 定格 (T+4) | 帧9 | 低 | 大气类（dust motes, embers floating）、光效 |

### 3.3 动作动词速查表 (Kinetic Verbs)

在描述战斗动作时，优先使用以下高冲击力动词：

| 类型 | 动词 |
|:---|:---|
| 攻击 | strike, smash, slash, thrust, punch, kick, slam, crush, pierce, shatter |
| 防御 | parry, block, deflect, dodge, evade, counter |
| 移动 | sprint, dash, lunge, vault, leap, dive, roll, slide, charge |
| 反应 | stagger, stumble, recoil, collapse, crumble, fly backward |
| 破坏 | explode, shatter, crack, splinter, crumble, disintegrate, rupture |

---

*版本: v1.0 | 基于 ActionVFX 专业分类、电影VFX工业标准整理*
