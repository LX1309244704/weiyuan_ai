---
name: KB_Lighting_Atmosphere
description: 提供从"视觉意图"到"光影方案"和"大气介质"的映射逻辑。用于为融合式提示词提供专业的灯光和氛围相关的英文技术参数。
version: 3.0.0
---

# Knowledge Base: Lighting & Atmosphere

本知识库提供从视觉意图到光影方案和大气介质的映射逻辑，用于为分镜提示词提供专业的灯光和氛围相关的英文技术参数。

## 1. 光影逻辑 (Lighting Logic)

*根据"视觉目标"或"情绪"，选择对应的布光方案关键词。*

### 1.1 光源类型参考 (Light Source Reference)

| 光源类型 | 英文关键词 | 特性描述 |
| :--- | :--- | :--- |
| 氙气灯 | Xenon Light | 强穿透力，适合大场景照明 |
| 烛光 | Candle Light | 点光源+闪烁频率，营造温馨或神秘感 |
| 激光 | Laser Light | 高能量束光源，科幻/现代感 |
| 霓虹灯管 | Neon Light | 线性光源，赛博朋克/都市感 |
| LED墙 | LED Wall | 柔和面光源，均匀照明 |
| 荧光灯 | Fluorescent Light | 冷色调面光源，办公/医院场景 |
| HMI灯 | HMI Light | 硬朗平行光，模拟日光 |
| **钨丝灯** | **Tungsten Light** | **暖色调点光源，复古/温馨氛围** |
| **镝灯** | **Daylight HMI** | **日光模拟，自然光效果** |

### 1.2 光质类型参考 (Light Quality Reference)

| 光质类型 | 英文关键词 | 视觉效果 |
| :--- | :--- | :--- |
| 轮廓光 | Rim Light | 分离主体与背景，勾勒轮廓 |
| 硬光 | Hard Light / Sharp Shadow | 表现刚硬、锐利，强烈阴影边缘 |
| 散光 | Diffused Light | 均匀照明，减少阴影 |
| 柔光 | Soft Shadow / Soft Light | 表现皮肤/丝绸质感，柔和过渡 |
| **聚光** | **Focused Light / Spotlight** | **突出主体，集中注意力** |
| **半硬光** | **Medium Shadow** | **平衡层次，介于硬光与柔光之间** |

### 1.3 光比参考 (Lighting Ratio Reference)

| 光比 | 英文表达 | 视觉效果 |
| :--- | :--- | :--- |
| 1:1 | Ratio 1:1, Flat Lighting | 平光，均匀无阴影 |
| 2:1 | Ratio 2:1, Gentle Contrast | 柔和对比，自然感 |
| 3:1 | Ratio 3:1, Dramatic | 戏剧性，标准人像布光 |
| 4:1 | Ratio 4:1, Strong Contrast | 强烈对比，情绪张力 |
| 5:1 | Ratio 5:1, Extreme Contrast | 极端对比，黑色电影风格 |

### 1.4 视觉意图映射表 (Intent to Lighting Mapping)

| 视觉目标 / 意图 (Intent) | 光源类型 (Source) | 光质 (Quality) | 光比 (Ratio) | 视觉提示词组合 (Prompts) |
| :--- | :--- | :--- | :--- | :--- |
| **突出建筑轮廓/结构** | 氙气灯 (Xenon), 烛光 (Candle) | 轮廓光 (Rim Light), 硬光 (Hard Light), 散光 (Diffused) | 2:1 (柔和), 3:1 (戏剧性) | `Xenon Light, Rim Light, Ratio 2:1` |
| **表现浪漫情调** | 激光 (Laser), 霓虹灯管 (Neon), LED墙 | 柔光 (Soft Shadow), 散光 (Diffused), 硬光 (Hard Light) | 2:1, 3:1, 4:1 | `Neon Light, Soft Shadow, Ratio 3:1` |
| **表现皮肤细腻/丝绸质感** | 激光 (Laser), LED墙, 荧光灯 (Fluorescent) | 柔光 (Soft Shadow), 散光 (Diffused), 轮廓光 (Rim Light) | 1:1 (平光), 4:1 (强对比) | `LED Wall, Soft Shadow, Ratio 1:1` |
| **增强空间层次感** | 荧光灯 (Fluorescent), LED墙, 激光 | 柔光 (Soft Shadow), 散光 (Diffused) | 1:1, 4:1 | `Fluorescent Light, Soft Shadow, Ratio 4:1` |
| **营造戏剧性/极端氛围** | 激光 (Laser), 烛光 (Candle) | 散光 (Diffused), 硬光 (Hard Light) | 5:1 (极端对比), 3:1 | `Laser, Diffused Light, Ratio 5:1` |
| **突出产品质感** | HMI灯 (平行光) | 散光 (Diffused) | 2:1 (柔和) | `HMI Light, Diffused Light, Ratio 2:1` |
| **模拟自然光** | 霓虹灯管, 氙气灯 | 散光 (Diffused), 轮廓光 (Rim Light) | 1:1, 4:1 | `Neon Light, Diffused Light, Ratio 1:1` |
| **营造悬疑氛围** | 烛光 (Candle), 钨丝灯 (Tungsten) | 硬光 (Hard Light), 聚光 (Focused Light) | 4:1, 5:1 (强对比) | `Candle Light, Hard Light, Ratio 5:1, Deep Shadows` |
| **表现金属的"锐度"** | HMI灯, 镝灯 (Daylight HMI) | 硬光 (Hard Light), 聚光 (Focused Light) | 3:1, 4:1 | `HMI Light, Hard Light, Ratio 4:1, Specular Highlights` |
| **营造温馨/怀旧氛围** | 钨丝灯 (Tungsten), 烛光 (Candle) | 柔光 (Soft Shadow), 半硬光 (Medium Shadow) | 2:1, 3:1 | `Tungsten Light, Soft Shadow, Ratio 2:1, Warm Tones` |
| **模拟日光/户外场景** | 镝灯 (Daylight HMI), HMI灯 | 散光 (Diffused), 半硬光 (Medium Shadow) | 2:1, 3:1 | `Daylight HMI, Diffused Light, Ratio 3:1, Natural Daylight` |

## 2. 场景氛围逻辑 (Scene Atmosphere)

*根据"应用场景"或"意图"，选择对应的"大气介质"与"镜头瑕疵"组合。*

### 2.1 大气介质参考 (Atmospheric Medium Reference)

| 大气介质 | 英文关键词 | 视觉效果 |
| :--- | :--- | :--- |
| 蒸汽 | Steam | 温暖、潮湿感，增强真实感 |
| 花粉 | Pollen | 空气体积感，春日氛围 |
| 雪 | Snow | 前景虚化，冬日/纯净感 |
| 雨 | Rain | 画面层次，情绪渲染 |
| 雾 | Fog | 神秘感，空间深度 |
| 尘 | Dust | 体积光效果，时间感 |
| 干冰 | Dry Ice | 梦幻/舞台效果 |
| 烟 | Smoke | 戏剧性，氛围渲染 |
| **露珠** | **Dew / Morning Dew** | **清新感，微距细节，自然美** |

### 2.2 镜头瑕疵参考 (Lens Artifacts Reference)

| 镜头瑕疵 | 英文关键词 | 视觉效果 |
| :--- | :--- | :--- |
| 渐晕 | Vignette | 引导视线，聚焦中心 |
| 镜头光晕 | Lens Flare | 光源存在感，电影质感 |
| 色差 | Chromatic Aberration | 复古/梦幻边缘效果 |
| 柔焦 | Soft Focus | 梦幻/浪漫质感 |
| 锐化过度 | Over Sharpening | 超现实/数码感 |
| 暗角 | Dark Corners | 戏剧性，框架感 |

### 2.3 应用场景映射表 (Intent to Atmosphere Mapping)

| 应用场景 / 意图 (Intent) | 推荐大气介质 (Atmosphere) | 推荐镜头瑕疵 (Artifacts) | 视觉提示词组合 (Prompts) |
| :--- | :--- | :--- | :--- |
| **表现时间流逝** | 蒸汽 (Steam), 烟雾 (Smoke), 雾 (Fog) | 渐晕 (Vignette), 镜头光晕 (Lens Flare), 色差 (Chromatic Aberration) | `Steam, Vignette` / `Fog, Vignette` |
| **产生空气体积感** | 花粉 (Pollen), 尘埃 (Dust) | 柔焦 (Soft Focus) | `Pollen, Soft Focus` / `Dust, Soft Focus` |
| **增加画面层次/前景虚化** | 雪 (Snow), 雨 (Rain) | 渐晕 (Vignette), 镜头光晕 (Lens Flare), 锐化过度 (Over Sharpening) | `Snow, Vignette` / `Rain, Vignette` |
| **营造神秘/梦幻氛围** | 雾 (Fog), 尘 (Dust), 干冰 (Dry Ice) | 色差 (Chromatic Aberration), 暗角 (Dark Corners), 锐化过度 | `Fog, Chromatic Aberration` / `Dust, Dark Corners` |
| **增强真实感** | 蒸汽 (Steam) | 柔焦 (Soft Focus) | `Steam, Soft Focus` |
| **突出主体与背景分离** | 雪 (Snow) | 暗角 (Dark Corners) | `Snow, Dark Corners` |
| **模拟电影质感** | 烟 (Smoke), 雾 (Fog), 尘 (Dust) | 渐晕 (Vignette), 镜头光晕 (Lens Flare), 色差 (Chromatic Aberration) | `Smoke, Vignette, Lens Flare, Film Grain` |
| **创造梦幻效果** | 雾 (Fog), 干冰 (Dry Ice), 花粉 (Pollen) | 柔焦 (Soft Focus), 色差 (Chromatic Aberration), 镜头光晕 (Lens Flare) | `Fog, Soft Focus, Dreamy Glow` / `Dry Ice, Chromatic Aberration` |
| **表现清晨/自然清新** | 露珠 (Dew), 雾 (Fog) | 柔焦 (Soft Focus), 镜头光晕 (Lens Flare) | `Morning Dew, Soft Focus, Golden Hour Light` |

## 3. 色彩系统 (Color System)

### 3.1 色温参考 (Color Temperature Reference)

| 色温范围 (K) | 描述 | 英文关键词 | 情绪/氛围 |
| :--- | :--- | :--- | :--- |
| 1800-2700K | 极暖光 | `Ultra Warm White`, `Candlelight`, `1800K` | 温馨、怀旧、浪漫、神秘 |
| 3000-3500K | 暖白光 | `Warm White`, `Golden Hour Light`, `3200K` | 舒适、亲密、黄金时刻 |
| 4000-5000K | 中性白 | `Neutral White`, `Natural Daylight`, `4500K` | 自然、真实、平衡、现代 |
| 5500-6500K | 日光白 | `Daylight White`, `Cool White`, `6500K` | 清晰、活力、临床、办公 |
| 7000-10000K+ | 冷蓝光 | `Cool Blue`, `Deep Blue Sky`, `8000K` | 冷峻、疏离、科幻、未来 |

### 3.2 饱和度参考 (Saturation Reference)

| 等级 | 描述 | 英文关键词 | 情绪/氛围 |
| :--- | :--- | :--- | :--- |
| -100 | 黑白 | `Black and White`, `Monochrome` | 经典、永恒、戏剧性、严肃 |
| -50 | 严重去饱和 | `Heavily Desaturated`, `Muted Tones` | 压抑、忧郁、末日、回忆 |
| -25 | 轻微去饱和 | `Slightly Desaturated`, `Subtle Colors` | 现实、冷静、高级感、纪录片 |
| 0 | 自然饱和 | `Natural Saturation`, `True to Life Colors` | 真实、平衡、自然 |
| +25 | 轻微过饱和 | `Slightly Oversaturated`, `Vibrant Colors` | 活力、热情、商业、乐观 |
| +50 | 高饱和 | `Highly Saturated`, `Rich Colors` | 梦幻、戏剧、波普艺术、儿童 |
| +75 | 极端饱和 | `Extremely Saturated`, `Hyper-real Colors` | 迷幻、超现实、视觉冲击 |

### 3.3 色彩基调参考 (Color Palette Reference)

| 基调类型 | 描述 | 英文关键词 | 情绪/氛围 |
| :--- | :--- | :--- | :--- |
| 单色 | 一种颜色的不同色调、明暗 | `Monochromatic Palette` | 统一、和谐、极简、宁静或压抑 |
| 类似色 | 色轮上相邻的颜色（如黄、黄绿、绿） | `Analogous Palette` | 和谐、舒适、自然、低对比度 |
| 互补色 | 色轮上相对的颜色（如红配绿，蓝配橙） | `Complementary Palette`, `Split-Toning` | 冲突、活力、高对比度、视觉焦点 |
| 三色 | 色轮上等距的三种颜色 | `Triadic Palette` | 平衡、多样、充满活力 |
| 粉彩色 | 高明度、低饱和度的颜色 | `Pastel Palette` | 柔和、梦幻、童话、女性化 |
| 大地色 | 棕色、米色、灰色等自然色 | `Earth Tone Palette` | 质朴、温暖、稳定、有机 |
| 霓虹色 | 极高饱和度的荧光色 | `Neon Palette`, `Cyberpunk Colors` | 未来、都市、迷幻、反乌托邦 |
